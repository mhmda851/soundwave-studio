import React, { useState, useRef, useEffect, useCallback } from "react";
import WaveformVisualizer from "../components/recorder/WaveformVisualizer";
import RecordButton from "../components/recorder/RecordButton";
import RecordingsList from "../components/recorder/RecordingsList";
import TimerDisplay from "../components/recorder/TimerDisplay";

export default function Recorder() {
  const [isRecording, setIsRecording] = useState(false);
  const [recordings, setRecordings] = useState([]);
  const [elapsed, setElapsed] = useState(0);
  const [analyserNode, setAnalyserNode] = useState(null);
  const [playingId, setPlayingId] = useState(null);

  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);
  const audioContextRef = useRef(null);
  const streamRef = useRef(null);
  const audioPlayerRef = useRef(null);

  const startRecording = useCallback(async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    streamRef.current = stream;

    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    audioContextRef.current = audioContext;
    const source = audioContext.createMediaStreamSource(stream);
    const analyser = audioContext.createAnalyser();
    analyser.fftSize = 128;
    source.connect(analyser);
    setAnalyserNode(analyser);

    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorderRef.current = mediaRecorder;
    chunksRef.current = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunksRef.current.push(e.data);
    };

    mediaRecorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      const url = URL.createObjectURL(blob);
      const now = new Date();
      setRecordings((prev) => [
        {
          id: Date.now(),
          url,
          name: `تسجيل ${prev.length + 1}`,
          date: now.toLocaleDateString("ar-SA"),
          time: now.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }),
          duration: elapsed,
          blob,
        },
        ...prev,
      ]);
    };

    mediaRecorder.start();
    setIsRecording(true);
    setElapsed(0);

    timerRef.current = setInterval(() => {
      setElapsed((prev) => prev + 1);
    }, 1000);
  }, [elapsed]);

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
    }
    clearInterval(timerRef.current);
    setIsRecording(false);
    setAnalyserNode(null);
  }, []);

  const deleteRecording = useCallback((id) => {
    setRecordings((prev) => prev.filter((r) => r.id !== id));
    if (playingId === id) {
      if (audioPlayerRef.current) audioPlayerRef.current.pause();
      setPlayingId(null);
    }
  }, [playingId]);

  const playRecording = useCallback((rec) => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
    }
    if (playingId === rec.id) {
      setPlayingId(null);
      return;
    }
    const audio = new Audio(rec.url);
    audioPlayerRef.current = audio;
    audio.play();
    setPlayingId(rec.id);
    audio.onended = () => setPlayingId(null);
  }, [playingId]);

  useEffect(() => {
    return () => {
      clearInterval(timerRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-start px-4 py-10 relative overflow-hidden">
      {/* Background decorative blobs */}
      <div className="fixed top-[-20%] left-[-10%] w-96 h-96 rounded-full opacity-20 blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, hsl(265 85% 55%), transparent)" }} />
      <div className="fixed bottom-[-10%] right-[-10%] w-80 h-80 rounded-full opacity-15 blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, hsl(200 90% 50%), transparent)" }} />
      <div className="fixed top-[40%] left-[60%] w-64 h-64 rounded-full opacity-10 blur-3xl pointer-events-none"
        style={{ background: "radial-gradient(circle, hsl(310 70% 50%), transparent)" }} />

      {/* Header */}
      <div className="w-full max-w-md mb-10 text-center animate-fade-slide-up">
        <div className="inline-flex items-center gap-2 mb-3 px-3 py-1 rounded-full glass-card">
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          <span className="text-xs text-muted-foreground font-medium tracking-widest uppercase">Voice Studio</span>
        </div>
        <h1 className="font-heading text-4xl font-bold gradient-text mb-2">مسجّل الصوت</h1>
        <p className="text-muted-foreground text-sm">سجّل صوتك بجودة عالية واحتفظ بلحظاتك</p>
      </div>

      {/* Main Recorder Card */}
      <div className="w-full max-w-md glass-card rounded-3xl p-8 mb-6 animate-fade-slide-up"
        style={{ animationDelay: "0.1s" }}>

        {/* Timer */}
        <TimerDisplay elapsed={elapsed} isRecording={isRecording} />

        {/* Waveform */}
        <div className="my-8">
          <WaveformVisualizer analyser={analyserNode} isRecording={isRecording} />
        </div>

        {/* Record Button */}
        <RecordButton
          isRecording={isRecording}
          onStart={startRecording}
          onStop={stopRecording}
        />

        {isRecording && (
          <p className="text-center text-xs text-muted-foreground mt-4 animate-pulse">
            جارٍ التسجيل... انقر لإيقافه
          </p>
        )}
      </div>

      {/* Recordings List */}
      {recordings.length > 0 && (
        <div className="w-full max-w-md animate-fade-slide-up" style={{ animationDelay: "0.2s" }}>
          <RecordingsList
            recordings={recordings}
            playingId={playingId}
            onPlay={playRecording}
            onDelete={deleteRecording}
          />
        </div>
      )}

      {recordings.length === 0 && !isRecording && (
        <div className="w-full max-w-md text-center py-8 animate-fade-slide-up" style={{ animationDelay: "0.2s" }}>
          <div className="text-5xl mb-3">🎙️</div>
          <p className="text-muted-foreground text-sm">لا توجد تسجيلات بعد<br />ابدأ تسجيلك الأول الآن</p>
        </div>
      )}
    </div>
  );
}