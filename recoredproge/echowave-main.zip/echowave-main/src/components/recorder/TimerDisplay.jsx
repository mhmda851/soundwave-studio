import React from "react";

function formatTime(seconds) {
  const m = Math.floor(seconds / 60).toString().padStart(2, "0");
  const s = (seconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function TimerDisplay({ elapsed, isRecording }) {
  return (
    <div className="flex flex-col items-center gap-2">
      {/* Timer digits */}
      <div
        className="font-mono text-5xl font-bold tracking-tight transition-all duration-300"
        style={{
          background: isRecording
            ? "linear-gradient(135deg, hsl(265 85% 80%), hsl(200 90% 75%))"
            : "linear-gradient(135deg, hsl(240 10% 60%), hsl(240 10% 50%))",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
          textShadow: "none",
          fontFamily: "'Space Grotesk', monospace",
          letterSpacing: "-0.02em",
        }}
      >
        {formatTime(elapsed)}
      </div>

      {/* Status indicator */}
      <div className="flex items-center gap-2">
        <div
          className={`w-2 h-2 rounded-full transition-all duration-300 ${
            isRecording ? "bg-red-500 animate-pulse" : "bg-muted-foreground/40"
          }`}
        />
        <span className="text-xs text-muted-foreground tracking-widest uppercase font-medium">
          {isRecording ? "يُسجَّل الآن" : "جاهز للتسجيل"}
        </span>
      </div>
    </div>
  );
}