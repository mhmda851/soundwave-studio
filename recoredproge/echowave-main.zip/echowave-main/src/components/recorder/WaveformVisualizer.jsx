import React, { useRef, useEffect, useState } from "react";

const BAR_COUNT = 48;

function getIdleHeights() {
  return Array.from({ length: BAR_COUNT }, (_, i) => {
    const x = i / BAR_COUNT;
    return 0.08 + 0.12 * Math.sin(x * Math.PI * 3) + 0.05 * Math.sin(x * Math.PI * 7);
  });
}

export default function WaveformVisualizer({ analyser, isRecording }) {
  const [bars, setBars] = useState(getIdleHeights());
  const animRef = useRef(null);
  const idleAnimRef = useRef(null);
  const idleOffsetRef = useRef(0);

  useEffect(() => {
    if (isRecording && analyser) {
      // Stop idle animation
      cancelAnimationFrame(idleAnimRef.current);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const tick = () => {
        analyser.getByteFrequencyData(dataArray);
        const newBars = Array.from({ length: BAR_COUNT }, (_, i) => {
          const idx = Math.floor((i / BAR_COUNT) * dataArray.length);
          const raw = dataArray[idx] / 255;
          return Math.max(0.04, raw);
        });
        setBars(newBars);
        animRef.current = requestAnimationFrame(tick);
      };
      animRef.current = requestAnimationFrame(tick);
    } else {
      cancelAnimationFrame(animRef.current);
      // Animate idle wave smoothly
      const animateIdle = () => {
        idleOffsetRef.current += 0.03;
        const offset = idleOffsetRef.current;
        const newBars = Array.from({ length: BAR_COUNT }, (_, i) => {
          const x = i / BAR_COUNT;
          return (
            0.08 +
            0.1 * Math.sin(x * Math.PI * 3 + offset) +
            0.06 * Math.sin(x * Math.PI * 7 + offset * 1.3) +
            0.04 * Math.sin(x * Math.PI * 13 + offset * 0.7)
          );
        });
        setBars(newBars);
        idleAnimRef.current = requestAnimationFrame(animateIdle);
      };
      idleAnimRef.current = requestAnimationFrame(animateIdle);
    }

    return () => {
      cancelAnimationFrame(animRef.current);
      cancelAnimationFrame(idleAnimRef.current);
    };
  }, [isRecording, analyser]);

  return (
    <div className="relative w-full">
      {/* Glow layer behind */}
      <div
        className="absolute inset-0 rounded-2xl blur-xl opacity-30 pointer-events-none"
        style={{
          background: isRecording
            ? "linear-gradient(to right, hsl(265 85% 55%), hsl(200 90% 60%))"
            : "linear-gradient(to right, hsl(240 10% 20%), hsl(240 10% 25%))",
          transition: "background 0.6s ease",
        }}
      />

      {/* Bars container */}
      <div
        className="relative flex items-center justify-center gap-[3px] h-24 w-full px-4"
        style={{ direction: "ltr" }}
      >
        {bars.map((h, i) => {
          const heightPct = Math.round(h * 100);
          const isCenter = Math.abs(i - BAR_COUNT / 2) < BAR_COUNT * 0.15;
          const opacity = isRecording
            ? 0.5 + h * 0.8
            : 0.35 + 0.35 * Math.abs(Math.sin((i / BAR_COUNT) * Math.PI));

          return (
            <div
              key={i}
              className={`flex-shrink-0 transition-all ${isRecording ? "waveform-bar" : "waveform-bar-idle"}`}
              style={{
                width: "3px",
                height: `${Math.max(6, heightPct)}%`,
                borderRadius: "999px",
                opacity,
                transform: `scaleY(1)`,
                transition: isRecording ? "height 0.05s ease, opacity 0.05s ease" : "height 0.1s ease, opacity 0.1s ease",
                background: isRecording
                  ? `linear-gradient(to top, hsl(265 85% ${45 + heightPct * 0.2}%), hsl(200 90% ${55 + heightPct * 0.15}%))`
                  : `linear-gradient(to top, hsl(240 10% 22%), hsl(240 10% 38%))`,
                boxShadow: isRecording && h > 0.4
                  ? `0 0 ${8 + h * 12}px hsl(265 85% 65% / ${h * 0.7})`
                  : "none",
              }}
            />
          );
        })}
      </div>

      {/* Center line decoration */}
      <div
        className="absolute left-4 right-4 h-px opacity-10 pointer-events-none"
        style={{
          top: "50%",
          background: "linear-gradient(to right, transparent, hsl(265 85% 65%), transparent)",
        }}
      />
    </div>
  );
}