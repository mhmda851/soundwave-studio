import React from "react";
import { Mic, Square } from "lucide-react";

export default function RecordButton({ isRecording, onStart, onStop }) {
  return (
    <div className="flex flex-col items-center gap-4">
      {/* Outer ring animation */}
      <div className="relative flex items-center justify-center">
        {/* Pulse rings */}
        {isRecording && (
          <>
            <div
              className="absolute rounded-full border border-primary/30 animate-ping"
              style={{ width: 100, height: 100, animationDuration: "1.5s" }}
            />
            <div
              className="absolute rounded-full border border-primary/20 animate-ping"
              style={{ width: 130, height: 130, animationDuration: "2s", animationDelay: "0.3s" }}
            />
            <div
              className="absolute rounded-full border border-accent/15 animate-ping"
              style={{ width: 160, height: 160, animationDuration: "2.5s", animationDelay: "0.6s" }}
            />
          </>
        )}

        {/* Main button */}
        <button
          onClick={isRecording ? onStop : onStart}
          className={`relative z-10 flex items-center justify-center rounded-full transition-all duration-300 focus:outline-none ${
            isRecording
              ? "bg-destructive/90 border-2 border-destructive animate-recording-pulse"
              : "glow-btn border-2 border-primary/60"
          }`}
          style={{
            width: 80,
            height: 80,
            background: isRecording
              ? "linear-gradient(135deg, hsl(0 72% 55%), hsl(0 80% 45%))"
              : "linear-gradient(135deg, hsl(265 85% 55%), hsl(285 80% 60%), hsl(200 90% 55%))",
          }}
        >
          {/* Inner glow */}
          <div
            className="absolute inset-0 rounded-full opacity-40"
            style={{
              background: isRecording
                ? "radial-gradient(circle at 35% 35%, rgba(255,100,100,0.6), transparent)"
                : "radial-gradient(circle at 35% 35%, rgba(200,180,255,0.5), transparent)",
            }}
          />

          {isRecording ? (
            <Square className="w-7 h-7 text-white fill-white relative z-10" />
          ) : (
            <Mic className="w-8 h-8 text-white relative z-10" />
          )}
        </button>
      </div>

      {/* Label */}
      <span
        className="text-xs font-medium tracking-wider uppercase transition-colors duration-300"
        style={{
          color: isRecording ? "hsl(0 72% 65%)" : "hsl(265 60% 70%)",
        }}
      >
        {isRecording ? "إيقاف التسجيل" : "ابدأ التسجيل"}
      </span>
    </div>
  );
}