import React from "react";
import { Play, Pause, Trash2, Download } from "lucide-react";

function formatDuration(seconds) {
  const m = Math.floor(seconds / 60).toString().padStart(2, "0");
  const s = (seconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

function RecordingItem({ rec, isPlaying, onPlay, onDelete }) {
  const handleDownload = () => {
    const a = document.createElement("a");
    a.href = rec.url;
    const date = new Date();
    const dateStr = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
    a.download = `${rec.name}-${dateStr}.webm`;
    a.click();
  };

  return (
    <div
      className={`glass-card rounded-2xl p-4 flex items-center gap-4 transition-all duration-300 ${
        isPlaying ? "border border-primary/40" : "border border-transparent hover:border-white/8"
      }`}
      style={{
        background: isPlaying
          ? "rgba(139, 92, 246, 0.08)"
          : "rgba(255,255,255,0.03)",
        boxShadow: isPlaying
          ? "0 0 20px hsl(265 85% 55% / 0.15)"
          : "none",
      }}
    >
      {/* Play button */}
      <button
        onClick={() => onPlay(rec)}
        className="flex-shrink-0 w-11 h-11 rounded-full flex items-center justify-center transition-all duration-200 focus:outline-none"
        style={{
          background: isPlaying
            ? "linear-gradient(135deg, hsl(265 85% 55%), hsl(200 90% 55%))"
            : "rgba(255,255,255,0.07)",
          boxShadow: isPlaying ? "0 0 16px hsl(265 85% 55% / 0.5)" : "none",
        }}
      >
        {isPlaying ? (
          <Pause className="w-4 h-4 text-white fill-white" />
        ) : (
          <Play className="w-4 h-4 text-muted-foreground fill-muted-foreground/60 ml-0.5" />
        )}
      </button>

      {/* Playback mini bars */}
      <div className="flex items-center gap-[2px] h-8 flex-shrink-0">
        {Array.from({ length: 16 }).map((_, i) => {
          const h = 20 + 60 * Math.abs(Math.sin((i / 16) * Math.PI * 3 + i * 0.4));
          return (
            <div
              key={i}
              className={`rounded-full transition-all duration-150 ${isPlaying ? "waveform-bar-playback" : "waveform-bar-idle"}`}
              style={{
                width: "2.5px",
                height: `${h}%`,
                opacity: isPlaying ? 0.7 + 0.3 * (i % 3 === 0 ? 1 : 0) : 0.3,
              }}
            />
          );
        })}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0" dir="rtl">
        <p className="text-sm font-medium text-foreground/90 truncate font-heading">{rec.name}</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          {rec.time} · {formatDuration(rec.duration)}
        </p>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1 flex-shrink-0">
        <button
          onClick={handleDownload}
          className="w-8 h-8 rounded-xl flex items-center justify-center text-muted-foreground/60 hover:text-accent hover:bg-accent/10 transition-all"
        >
          <Download className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => onDelete(rec.id)}
          className="w-8 h-8 rounded-xl flex items-center justify-center text-muted-foreground/60 hover:text-destructive hover:bg-destructive/10 transition-all"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

export default function RecordingsList({ recordings, playingId, onPlay, onDelete }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-4 px-1" dir="rtl">
        <h2 className="text-sm font-semibold text-foreground/70 font-heading tracking-wide">التسجيلات</h2>
        <div className="flex-1 h-px bg-border/50" />
        <span className="text-xs text-muted-foreground bg-secondary rounded-full px-2 py-0.5">
          {recordings.length}
        </span>
      </div>

      <div className="flex flex-col gap-3 max-h-96 overflow-y-auto scrollbar-hide pb-4">
        {recordings.map((rec, idx) => (
          <div
            key={rec.id}
            className="animate-fade-slide-up"
            style={{ animationDelay: `${idx * 0.05}s` }}
          >
            <RecordingItem
              rec={rec}
              isPlaying={playingId === rec.id}
              onPlay={onPlay}
              onDelete={onDelete}
            />
          </div>
        ))}
      </div>
    </div>
  );
}